package group.again;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AgainApplication {

	public static void main(String[] args) {
		SpringApplication.run(AgainApplication.class, args);
	}

}
