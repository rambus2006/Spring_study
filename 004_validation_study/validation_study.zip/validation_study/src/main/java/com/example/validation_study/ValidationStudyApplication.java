package com.example.validation_study;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ValidationStudyApplication {

	public static void main(String[] args) {
		SpringApplication.run(ValidationStudyApplication.class, args);
	}

}
