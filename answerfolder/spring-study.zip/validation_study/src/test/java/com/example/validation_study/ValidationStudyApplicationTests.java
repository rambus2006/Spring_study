package com.example.validation_study;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ValidationStudyApplicationTests {

	@Test
	void contextLoads() {
	}

}
