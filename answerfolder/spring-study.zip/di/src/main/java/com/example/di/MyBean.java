package com.example.di;

import org.springframework.stereotype.Component;

@Component
public class MyBean {

}
